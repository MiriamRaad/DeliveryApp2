import { Component, OnInit } from '@angular/core';
import { Service } from '../Service';

@Component({
  selector: 'order-card',
  templateUrl: './order-card.component.html',
  styleUrls: ['./order-card.component.css']
})
export class OrderCardComponent implements OnInit {

  Orders= [] as any
  TotalItems = 0
  Price = this.gettotalprice()

  constructor(public Serv :Service )
  {
    this.Orders= this.Serv.getOrders();
    this.TotalItems = this.Serv.Order.length;

  }

  gettotalprice()
  {
    var price=0

    for ( let i of this.Serv.getOrders())
    {
      
      price += (i.Price * i.Quantity)
    
    }

    return price  
  }
  
  ngOnInit(): void {

  }

}
