import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'order-card',
  templateUrl: './order-card.component.html',
  styleUrls: ['./order-card.component.css']
})
export class OrderCardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
