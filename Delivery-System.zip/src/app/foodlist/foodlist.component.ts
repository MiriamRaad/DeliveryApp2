import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'foodlist',
  templateUrl: './foodlist.component.html',
  styleUrls: ['./foodlist.component.css']
})
export class FoodlistComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
