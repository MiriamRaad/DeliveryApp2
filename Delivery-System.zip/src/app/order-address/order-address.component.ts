import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'order-address',
  templateUrl: './order-address.component.html',
  styleUrls: ['./order-address.component.css']
})
export class OrderAddressComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
